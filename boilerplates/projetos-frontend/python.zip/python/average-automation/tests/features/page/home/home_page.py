class HomePage:
    def valida_home_page():
        pass