from selenium import webdriver

def before_all(context):
    context.driver = webdriver.Chrome()
    context.driver.implicitly_wait(5)

def before_scenario(context, scenario):
    print(f'Before Scenario: {scenario} running...')

def after_step(context, step):
    print(f'After Step name: {step} finish...')

def after_all(context):
    context.driver.quit()