from behave import given, when, then
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

base_url                = 'https://www.google.com/'
path_screenshot         = '/Users/agnaldovilariano/Documents/projetos/quality-software-naldo/projetos-frontend/python/basic-automation/tests/results/evidencias/result.png'

campo_pesquisa_css      = 'div>textarea.gLFyf'
bt_pesquisa_css         = 'center>input[value="Pesquisa Google"]'
especific_text_css      = 'div.DoxwDb>div'

campo_pesquisa_xpath    = '/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/textarea'
bt_pesquisa_xpath       = '//*/div[@class="lJ9FBc"]/center/input[@value="Pesquisa Google"]'
especific_text_xpath    = '//*/div[@data-attrid="title"]'

@given(u'que acesso a pagina do google')
def step_impl(context):
    # acessa base_url no navegador
    context.driver.get(base_url)
    # salva a url atual do navegador em uma variavel
    atual_url = context.driver.current_url
    # verifica se a url inicial é a esperada
    assert atual_url == base_url, f'A página inicial não está no endereço correto.\nUrl Esperada: {base_url}\nUrl Atial: {atual_url}'

@given(u'insiro o texto {texto_pesquisa} no campo de pesquisa')
def step_impl(context, texto_pesquisa):
    # busca um campo CSS_SELECTOR ou XPATH na pagina html e grava em uma variavel
    ell_pesquisa = context.driver.find_element(By.CSS_SELECTOR, campo_pesquisa_css)
    # ell_pesquisa = context.driver.find_element(By.XPATH, campo_pesquisa_xpath)
    
    # envia o texto_pesquisa para o campo de pesquisa
    ell_pesquisa.send_keys(texto_pesquisa)

@when(u'clico no botao de pesquisa')
def step_impl(context):
    # busca um campo CSS_SELECTOR ou XPATH na pagina html e grava em uma variavel
    ell_bt_pesquisa = context.driver.find_element(By.CSS_SELECTOR, bt_pesquisa_css)
    # ell_bt_pesquisa = context.driver.find_element(By.XPATH, bt_pesquisa_xpath)
    
    # clica no botao de pesquisa
    ell_bt_pesquisa.click()

@then(u'vejo resultados da pesquisa')
def step_impl(context):
    # salva um screenshot da tela de resultados em uma pasta especifica
    context.driver.save_screenshot('/Users/agnaldovilariano/Documents/projetos/quality-software-naldo/projetos-frontend/python/basic-automation/tests/results/evidencias/Imperativos/result_css.png')
    # context.driver.save_screenshot('/Users/agnaldovilariano/Documents/projetos/quality-software-naldo/projetos-frontend/python/basic-automation/tests/results/evidencias/Imperativos/result_xpath.png')

@then(u'valido se o texto {texto_valida} aparece na pagina de resultados')
def step_impl(context, texto_valida):
    # busca um campo CSS_SELECTOR ou XPATH na pagina html e grava em uma variavel
    ell_especific_text = context.driver.find_element(By.CSS_SELECTOR, especific_text_css)
    # ell_especific_text = context.driver.find_element(By.XPATH, especific_text_xpath)
    # valida se o texto de texto_valida existe no campo especifico de ell_especific_text
    assert texto_valida in ell_especific_text.text, f'Não foi encontrado o texto {texto_valida} na página de resultados'
    # Valida se texto de texto_valida existe na pagina corrente
    assert texto_valida in context.driver.page_source, f'Não foi encontrado o texto {texto_valida} na página de resultados'