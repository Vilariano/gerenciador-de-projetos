from behave import when, then
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

campo_pesquisa_css      = 'div>textarea.gLFyf'
bt_pesquisa_css         = 'center>input[value="Pesquisa Google"]'
especific_text_css      = 'div.DoxwDb>div'

campo_pesquisa_xpath    = '/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/textarea'
bt_pesquisa_xpath       = '//*/div[@class="lJ9FBc"]/center/input[@value="Pesquisa Google"]'
especific_text_xpath    = '//*/div[@data-attrid="title"]'

@when(u'pesquiso por {texto_pesquisa}')
def step_impl(context, texto_pesquisa):
    # ell_pesquisa = context.driver.find_element(By.CSS_SELECTOR, campo_pesquisa_css)
    ell_pesquisa = context.driver.find_element(By.XPATH, campo_pesquisa_xpath)
    ell_pesquisa.send_keys(texto_pesquisa)
    # ell_bt_pesquisa = context.driver.find_element(By.CSS_SELECTOR, bt_pesquisa_css)
    ell_bt_pesquisa = context.driver.find_element(By.XPATH, bt_pesquisa_xpath)
    ell_bt_pesquisa.click()

@then(u'valido se {texto_valida} e exibido na tela')
def step_impl(context, texto_valida):
    context.driver.save_screenshot('/Users/agnaldovilariano/Documents/projetos/quality-software-naldo/projetos-frontend/python/basic-automation/tests/results/evidencias/Declarativos/result_xpath.png')
    # context.driver.save_screenshot('/Users/agnaldovilariano/Documents/projetos/quality-software-naldo/projetos-frontend/python/basic-automation/tests/results/evidencias/Declarativos/result_css.png')
    # ell_especific_text = context.driver.find_element(By.CSS_SELECTOR, especific_text_css)
    ell_especific_text = context.driver.find_element(By.XPATH, especific_text_xpath)
    # valida se o texto de texto_valida existe no campo especifico de ell_especific_text
    assert texto_valida in ell_especific_text.text, f'Não foi encontrado o texto {texto_valida} na página de resultados'
    # Valida se texto de texto_valida existe na pagina corrente
    assert texto_valida in context.driver.page_source, f'Não foi encontrado o texto {texto_valida} na página de resultados'