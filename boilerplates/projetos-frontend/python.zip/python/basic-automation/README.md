# Basic Automation
 - Automatizando Testes com Python, Selenium e Behave

# Pré requisitos:
- Python 3.6+
- PIP
- Virtualenv (iremos instalar com o PIP)
- Selenium (iremos instalar com o PIP)
- Behave (iremos instalar com o PIP)
- Driver de um Browser¹: Google Chrome ou Mozilla Firefox.

# Documentação de estudos
[behave 1.2.7.dev7 documentation](https://behave.readthedocs.io/en/latest/)<br>
[Gherkin: Introduzindo seus conceitos e benefícios](https://blog.onedaytesting.com.br/gherkin/)<br>
[GHERKIN – Imperativo X Declarativo](https://cwi.com.br/blog/gherkin-imperativo-x-declarativo/)

# Curso Python Selenium com o mestre Eduardo Mendes
[Aula focada Behave Python](https://youtu.be/BMrDPStzHcI?list=PLOQgLBuj2-3LqnMYKZZgzeC7CKCPF375B)<br>
[Curso completo Python Selenium](https://www.youtube.com/live/PHHXksljGNA?si=wNB-9btNJxyE25UE)

# curso completo na Udemy
[Python do Zero à Automação](https://www.udemy.com/course/python-do-zero-a-automacao)

## INSTALAÇÃO
### Instalação de dependências:
```sh
python3 -m venv .env # para criar o ambiente virtualenv
source .env/bin/activate # para iniciar o ambiente virtualenv
pip install -r requirements/requirements.txt # para instalar as dependencias do projeto
```

## Arquivo requirements:
- Como o arquivo de Requirements deve ficar:
    ![Requirements](img/requirements.png)

## Cenários imperativos x Cenários declarativos
- Cenários Imperativos
```sh
@CenarioImperativos
Cenario: Imperativos Pesquisa com sucesso
    Dado que acesso a pagina do google
    E insiro o texto Python no campo de pesquisa
    Quando clico no botao de pesquisa
    Então vejo resultados da pesquisa
    E valido se o texto Python aparece na pagina de resultados
```
- Cenários Declarativos
```sh
@CenarioDeclarativos
Cenario: Declarativos Pesquisa com sucesso
    Dado que acesso a pagina do google
    Quando pesquiso por Python
    Então Python e exibido na resultados
```
## EXECUÇÃO DO PROJETO
- Estriutura do projeto inicial:<br>
    ![estrutura de testes](img/estrutura_inicial.png)

- Executar projeto sem parametros
    ```sh
    behave
    ```
    Ex:
    <br>![estrutura de testes](img/behave.png)
- Executar projeto usadno Tag do cenario
    ```sh
    behave -t @CenarioImperativos -k
    ```
    Ex:
    <br>![estrutura de testes](img/behave_tag.png)
- Executar com feature especifica:
    ```sh
    behave features/specs/GoogleCenarioImperativos.feature -k
    ```
    Ex:
    <br>![estrutura de testes](img/behave_feature.png)
- Executar projeto salvando resultados ex Tag com Relatorio:
    ```sh
    behave -t @CenarioImperativos -f html -o=results/report.html -k
    ```
    Ex:
    <br>![estrutura de testes](img/behave_tag_report.png)
- Executar projeto salvando resultados ex Feature com Relatorio:
    ```sh
    behave features/specs/GoogleCenarioImperativos.feature -f html -o=results/report.html -k
    ```
    Ex:
    <br>![estrutura de testes](img/behave_feature_report.png)

### Implementando steps Declarativos
- Dado que acesso a pagina do google:
<br>![estrutura de testes](img/cenarios/Declarativos/Screenshot%202024-10-28%20at%2019.30.02.png)
- Quando pesquiso por Python
<br>![estrutura de testes](img/cenarios/Declarativos/Screenshot%202024-10-28%20at%2019.36.17.png)
- Então valido se Python e exibido na tela
<br>![estrutura de testes](img/cenarios/Declarativos/Screenshot%202024-10-28%20at%2019.36.36.png)

### Implementando steps Imperativos
- Dado que acesso a pagina do google:
<br>![estrutura de testes](img/cenarios/Imperativos/Screenshot%202024-10-28%20at%2019.30.02.png)
- E insiro o texto Python no campo de pesquisa
<br>![estrutura de testes](img/cenarios/Imperativos/Screenshot%202024-10-28%20at%2019.31.06.png)
- Quando clico no botao de pesquisa
<br>![estrutura de testes](img/cenarios/Imperativos/Screenshot%202024-10-28%20at%2019.32.04.png)
- Então vejo resultados da pesquisa
<br>![estrutura de testes](img/cenarios/Imperativos/Screenshot%202024-10-28%20at%2019.32.27.png)
- E valido se o texto Python aparece na pagina de resultados
<br>![estrutura de testes](img/cenarios/Imperativos/Screenshot%202024-10-28%20at%2019.32.53.png)

### Estrutura final do projeto:
- Estriutura do projeto inicial:<br>
    ![estrutura de testes](img/estrutura_final.png)

### Execução geral e Relatorio
- Executando todos os cenarios
<br>![estrutura de testes](img/cenarios/Results/Screenshot%202024-10-28%20at%2019.41.29.png)
- Relatorio html
<br>![estrutura de testes](img/cenarios/Results/Screenshot%202024-10-28%20at%2019.37.12.png)

# Seu relatorio ta igual ao exemple a cima?
![estrutura de testes](img/comemora.gif)

# Parabens você finalizou a fase basica da automação web com Python e Behave 🥇🏆🎉🎊🎈