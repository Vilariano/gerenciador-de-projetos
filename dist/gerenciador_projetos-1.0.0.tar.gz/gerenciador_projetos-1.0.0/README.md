# Gerenciador de Projetos

Uma ferramenta para gerenciar e extrair templates de projetos predefinidos.

## Instalação

```bash
pip install gerenciador-projetos
